package com.example.service;

import com.example.repository.BookRepository;

public class BookService {

    private BookRepository bookRepository;

    // Setter method for BookRepository
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Method to use BookRepository's findBookById method
    public void findBook(int id) {
        System.out.println("BookService: Searching for book with ID: " + id);
        if (bookRepository != null) {
            bookRepository.findBookById(id);
        } else {
            System.out.println("BookRepository is not set.");
        }
    }
}
