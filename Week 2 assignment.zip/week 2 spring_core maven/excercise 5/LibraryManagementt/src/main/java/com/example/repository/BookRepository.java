package com.example.repository;




public class BookRepository {

    

    public BookRepository() {
       
    }

   
    public void findBookById(int id) {
        
        System.out.println("Finding book with ID: " + id);
    }
}

