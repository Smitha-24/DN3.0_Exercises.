
import java.util.ArrayList;
import java.util.List;

public class InventoryManager
{
    private List<Product> inventory;

  
    public InventoryManager() 
    {
        inventory = new ArrayList<>();
    }

   
    public void addProduct(Product product) 
    {
        inventory.add(product);
    }

  
    public void updateProduct(Product product) 
    {
        for (int i = 0; i < inventory.size(); i++) 
        {
            if (inventory.get(i).getProductId().equals(product.getProductId()))
            {
                inventory.set(i, product);
                return;
            }
        }
        System.out.println("Product not found.");
    }

    public void deleteProduct(String productId) 
    {
        inventory.removeIf(product -> product.getProductId().equals(productId));
    }

  
    public Product getProduct(String productId) 
    {
        for (Product product : inventory) 
        {
            if (product.getProductId().equals(productId))
            {
                return product;
            }
        }
        return null;
    }

   
    public void listAllProducts() 
    {
        for (Product product : inventory) 
        {
            System.out.println(product);
        }
    }
}
