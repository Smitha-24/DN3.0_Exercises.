package excercise4;

	public class Main {
	    public static void main(String[] args) {
	        
	        EmployeeManager manager = new EmployeeManager(5);

	        
	        manager.addEmployee(new Employee(1, "Alice", "Developer", 70000));
	        manager.addEmployee(new Employee(2, "Bob", "Designer", 60000));
	        manager.addEmployee(new Employee(3, "Charlie", "Manager", 80000));
	        manager.addEmployee(new Employee(4, "Diana", "Analyst", 55000));
	        manager.addEmployee(new Employee(5, "Edward", "Tester", 50000));

	       
	        System.out.println("All Employees:");
	        manager.traverseEmployees();

	       
	        int searchId = 3;
	        Employee employee = manager.searchEmployee(searchId);
	        if (employee != null) {
	            System.out.println("\nFound Employee with ID " + searchId + ":");
	            System.out.println(employee);
	        } else {
	            System.out.println("\nEmployee with ID " + searchId + " not found.");
	        }

	        
	        int deleteId = 2;
	        boolean deleted = manager.deleteEmployee(deleteId);
	        if (deleted) {
	            System.out.println("\nEmployee with ID " + deleteId + " deleted successfully.");
	        } else {
	            System.out.println("\nEmployee with ID " + deleteId + " not found.");
	        }

	        
	        System.out.println("\nAll Employees After Deletion:");
	        manager.traverseEmployees();
	    }
	}



