package excercise5;


	public class Main {
	    public static void main(String[] args) {
	        
	        TaskManager taskManager = new TaskManager();

	        
	        taskManager.addTask(new Task(1, "Design Homepage", "In Progress"));
	        taskManager.addTask(new Task(2, "Develop Backend API", "Completed"));
	        taskManager.addTask(new Task(3, "Write Documentation", "Not Started"));
	        taskManager.addTask(new Task(4, "Test Application", "In Progress"));

	        
	        System.out.println("All Tasks:");
	        taskManager.traverseTasks();

	       
	        int searchId = 3;
	        Task task = taskManager.searchTask(searchId);
	        if (task != null) {
	            System.out.println("\nFound Task with ID " + searchId + ":");
	            System.out.println(task);
	        } else {
	            System.out.println("\nTask with ID " + searchId + " not found.");
	        }

	        
	        int deleteId = 2;
	        boolean deleted = taskManager.deleteTask(deleteId);
	        if (deleted) {
	            System.out.println("\nTask with ID " + deleteId + " deleted successfully.");
	        } else {
	            System.out.println("\nTask with ID " + deleteId + " not found.");
	        }

	       
	        System.out.println("\nAll Tasks After Deletion:");
	        taskManager.traverseTasks();
	    }
	}


