package excercise6;


	import java.util.Arrays;

	public class Main {
	    public static void main(String[] args) {
	        
	        Book[] books = {
	            new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"),
	            new Book(2, "Moby Dick", "Herman Melville"),
	            new Book(3, "To Kill a Mockingbird", "Harper Lee"),
	            new Book(4, "1984", "George Orwell")
	        };

	        
	        System.out.println("Books before sorting:");
	        for (Book book : books) {
	            System.out.println(book);
	        }

	        
	        BookSearch.sortBooksByTitle(books);

	    
	        System.out.println("\nBooks after sorting:");
	        for (Book book : books) {
	            System.out.println(book);
	        }

	        
	        String searchTitleLinear = "Moby Dick";
	        Book foundBookLinear = BookSearch.linearSearchByTitle(books, searchTitleLinear);
	        System.out.println("\nLinear Search Result for \"" + searchTitleLinear + "\":");
	        System.out.println(foundBookLinear != null ? foundBookLinear : "Book not found");

	       
	        String searchTitleBinary = "1984";
	        Book foundBookBinary = BookSearch.binarySearchByTitle(books, searchTitleBinary);
	        System.out.println("\nBinary Search Result for \"" + searchTitleBinary + "\":");
	        System.out.println(foundBookBinary != null ? foundBookBinary : "Book not found");
	    }
	}



