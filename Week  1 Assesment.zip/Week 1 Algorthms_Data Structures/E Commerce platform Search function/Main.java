package exercise2;


	import java.util.Arrays;
	import java.util.Comparator;

	public class Main {
	    public static void main(String[] args) {
	        // Sample products
	        Product[] products = {
	                new Product(1, "Laptop", "Electronics"),
	                new Product(2, "Smartphone", "Electronics"),
	                new Product(3, "Book", "Education"),
	                new Product(4, "Headphones", "Electronics"),
	                new Product(5, "Coffee Mug", "Kitchen")
	        };

	        // Linear Search
	        int targetProductId = 3;
	        Product result = linearSearch(products, targetProductId);
	        System.out.println("Linear Search Result: " + result);

	        // Binary Search (products need to be sorted by productId)
	        Arrays.sort(products, Comparator.comparingInt(Product::getProductId));

	        result = binarySearch(products, targetProductId);
	        System.out.println("Binary Search Result: " + result);
	    }

	    public static Product linearSearch(Product[] products, int targetProductId) {
	        for (Product product : products) {
	            if (product.getProductId() == targetProductId) {
	                return product;
	            }
	        }
	        return null;
	    }

	    public static Product binarySearch(Product[] products, int targetProductId) {
	        int left = 0;
	        int right = products.length - 1;

	        while (left <= right) {
	            int mid = (left + right) / 2;
	            if (products[mid].getProductId() == targetProductId) {
	                return products[mid];
	            } else if (products[mid].getProductId() < targetProductId) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }
	        return null;
	    }
	}

	class Product {
	    private int productId;
	    private String productName;
	    private String category;

	    public Product(int productId, String productName, String category) {
	        this.productId = productId;
	        this.productName = productName;
	        this.category = category;
	    }

	    public int getProductId() {
	        return productId;
	    }

	    public String getProductName() {
	        return productName;
	    }

	    public String getCategory() {
	        return category;
	    }

	    @Override
	    public String toString() {
	        return "Product{" +
	                "productId=" + productId +
	                ", productName='" + productName + '\'' +
	                ", category='" + category + '\'' +
	                '}';
	    }
	}



