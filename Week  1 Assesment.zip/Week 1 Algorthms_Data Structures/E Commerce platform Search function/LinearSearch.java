package exercise2;

public class LinearSearch {
	
	    public static Product linearSearch(Product[] products, int targetProductId) {
	        for (Product product : products) {
	            if (product.getProductId() == targetProductId) {
	                return product;
	            }
	        }
	        return null;
	    }
	}



