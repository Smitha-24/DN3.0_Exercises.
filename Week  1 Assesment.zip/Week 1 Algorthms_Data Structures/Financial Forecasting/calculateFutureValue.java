package exercise7;

public class calculateFutureValue {
	public static double calculateFutureValueIterative(double presentValue, double annualGrowthRate, int periods) {
	    double futureValue = presentValue;
	    for (int i = 0; i < periods; i++) {
	        futureValue *= (1 + annualGrowthRate);
	    }
	    return futureValue;
	}

	

}
