package excercise12;


	public interface Notifier {
	    void send(String message);
	}



