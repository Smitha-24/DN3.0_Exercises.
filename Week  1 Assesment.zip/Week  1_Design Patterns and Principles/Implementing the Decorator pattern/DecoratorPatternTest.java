package excercise12;


	public class DecoratorPatternTest {
	    public static void main(String[] args) {
	        
	        Notifier emailNotifier = new EmailNotifier();

	     
	        Notifier smsEmailNotifier = new SMSNotifierDecorator(emailNotifier);

	        
	        Notifier slackEmailNotifier = new SlackNotifierDecorator(emailNotifier);

	       
	        Notifier combinedNotifier = new SlackNotifierDecorator(new SMSNotifierDecorator(emailNotifier));

	        
	        emailNotifier.send("Hello World!");
	        smsEmailNotifier.send("Hello World with SMS!");
	        slackEmailNotifier.send("Hello World with Slack!");
	        combinedNotifier.send("Hello World with SMS and Slack!");
	    }
	}



