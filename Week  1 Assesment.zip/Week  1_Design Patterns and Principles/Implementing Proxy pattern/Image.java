package excercise13;


	public interface Image {
	    void display();
	}



