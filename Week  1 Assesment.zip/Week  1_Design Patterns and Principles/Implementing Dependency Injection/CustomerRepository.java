package excercise18;


	public interface CustomerRepository {
	    String findCustomerById(String id);
	}



