package excercise9;


	public abstract class DocumentFactory {
	    public abstract Document createDocument();
	}


