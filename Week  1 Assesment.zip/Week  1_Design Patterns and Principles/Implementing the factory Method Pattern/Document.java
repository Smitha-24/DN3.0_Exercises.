package excercise9;

public interface Document {
	
	    void open();
	    void close();
	}



