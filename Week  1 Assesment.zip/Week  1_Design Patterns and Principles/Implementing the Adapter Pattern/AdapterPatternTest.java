package excercise11;


	public class AdapterPatternTest {
	    public static void main(String[] args) {
	
	        PayPalPayment payPalPayment = new PayPalPayment();
	        StripePayment stripePayment = new StripePayment();

	       
	        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalPayment);
	        PaymentProcessor stripeAdapter = new StripeAdapter(stripePayment);

	        
	        payPalAdapter.processPayment(100.00);
	        stripeAdapter.processPayment(150.00);
	    }
	}



