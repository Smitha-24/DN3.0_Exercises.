package excercise11;

public class StripePayment {
	
	    public void charge(double amount) {
	        System.out.println("Charging $" + amount + " through Stripe.");
	    }
	}


