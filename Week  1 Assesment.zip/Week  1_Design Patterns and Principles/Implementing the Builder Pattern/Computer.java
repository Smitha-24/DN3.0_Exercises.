package excercise10;


	public class Computer {
	    private final String CPU;
	    private final String RAM;
	    private final String storage;
	    private final boolean graphicsCard;
	    private final boolean bluetooth;

	    private Computer(Builder builder) {
	        this.CPU = builder.CPU;
	        this.RAM = builder.RAM;
	        this.storage = builder.storage;
	        this.graphicsCard = builder.graphicsCard;
	        this.bluetooth = builder.bluetooth;
	    }

	    @Override
	    public String toString() {
	        return "Computer [CPU=" + CPU + ", RAM=" + RAM + ", Storage=" + storage +
	               ", Graphics Card=" + graphicsCard + ", Bluetooth=" + bluetooth + "]";
	    }

	    public static class Builder {
	        private final String CPU;
	        private final String RAM;
	        private String storage;
	        private boolean graphicsCard;
	        private boolean bluetooth;

	        public Builder(String CPU, String RAM) {
	            this.CPU = CPU;
	            this.RAM = RAM;
	        }

	        public Builder setStorage(String storage) {
	            this.storage = storage;
	            return this;
	        }

	        public Builder setGraphicsCard(boolean graphicsCard) {
	            this.graphicsCard = graphicsCard;
	            return this;
	        }

	        public Builder setBluetooth(boolean bluetooth) {
	            this.bluetooth = bluetooth;
	            return this;
	        }

	        public Computer build() {
	            return new Computer(this);
	        }
	    }
	}



