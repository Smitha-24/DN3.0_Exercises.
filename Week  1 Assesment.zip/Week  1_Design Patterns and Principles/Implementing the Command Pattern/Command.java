package excercise16;


	public interface Command {
	    void execute();
	}


